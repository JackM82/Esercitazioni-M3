window.onload = function () {
   let sections = document.getElementsByClassName("visibile");
   sections[0].classList.add("animVis1");
   sections[1].classList.add("animVis2");
   sections[2].classList.add("animVis3");
}










